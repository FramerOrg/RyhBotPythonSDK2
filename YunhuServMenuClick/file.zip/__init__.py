moduleInfo = {
    "author": "r1a",
    "description": "YunhuServer - Menu Click Message Handler",
    "hooker": False,
}

from .module import moduleMain
