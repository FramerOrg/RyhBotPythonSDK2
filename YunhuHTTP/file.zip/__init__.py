moduleInfo = {
    "author": "r1a",
    "description": "YunhuAPI - HTTP Request Encapsulation",
    "hooker": False,
}

from .module import moduleMain
