import json
import pathlib
import functools
import flask


class moduleMain:
    def __init__(self, framer, logger):
        self.framer = framer
        self.logger = logger

        self.app = flask.Flask(__name__)
        self.triggers = {}
        self.use_pipe = False
        self.requests = []

    def __call__(self, t):
        on = t.on
        if on not in self.triggers:
            self.triggers[on] = []
        self.triggers[on].append(t)

    def UsePipe(self, use_pipe):
        self.use_pipe = use_pipe

    def RegisterPath(self, path, methods, func):
        self.app.route(path, methods=methods)(func)

    def ServAPI(self, *func):
        def loop_call(path):
            for f in func:
                result = f(path)
                if result != None:
                    return result
            return "Not Found"

        self.RegisterPath(
            "/api/<path:path>",
            methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
            func=loop_call,
        )

    def ServWeb(self, base):
        www_dir = pathlib.Path(base).resolve()

        def send_file(path=""):
            nonlocal www_dir
            return (
                flask.send_from_directory(www_dir, path)
                if path
                else flask.send_from_directory(www_dir, "index.html")
            )

        self.RegisterPath("/", methods=["GET"], func=send_file)
        self.RegisterPath("/public/<path:path>", methods=["GET"], func=send_file)

    def ServYunhu(self):
        data = json.loads(flask.request.data.decode("utf-8"))
        if self.use_pipe:
            self.requests.append(data)
            return "OK"
        on = data["header"]["eventType"]
        if on in self.triggers:
            for t in self.triggers[on]:
                t.OnRecv(data)
        return "OK"

    def T(self, on="all"):
        return functools.partial(self.Trigger, on)

    def Trigger(self, on):
        if self.use_pipe and self.requests:
            if on == "all":
                return self.requests.pop(0)
            for i, req in enumerate(self.requests):
                if req["header"]["eventType"] == on:
                    return self.requests.pop(i)
        return None

    def Start(self):
        self.RegisterPath("/yunhu", methods=["POST"], func=self.ServYunhu)
        self.app.run(
            host=self.framer.env.yunhu_server_host,
            port=self.framer.env.yunhu_server_port,
            threaded=True,
        )
