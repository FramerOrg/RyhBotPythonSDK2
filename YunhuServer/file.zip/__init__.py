moduleInfo = {
    "author": "r1a",
    "description": "YunhuAPI - HTTP Server Module",
    "hooker": False,
}

from .module import moduleMain
