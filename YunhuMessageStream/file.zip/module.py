class moduleMain:
    def __init__(self, framer, logger):
        self.framer = framer
        self.logger = logger
        self.contentType = "text"

    def New(self, contentType):
        self.contentType = contentType
        return self

    def To(self, recvType, recvId):
        return self.framer.YunhuHTTP.stream(recvId, recvType, self.contentType)
