moduleInfo = {
    "author": "r1a",
    "description": "YunhuAPI - Stream Send Module",
    "hooker": False,
}

from .module import moduleMain
