class moduleMain:
    def __init__(self, framer, logger):
        self.framer = framer
        self.logger = logger

        self.all_packages = [
            "YunhuHTTP",
            "YunhuMessageBatch",
            "YunhuMessageBoard",
            "YunhuMessageEdit",
            "YunhuMessageHistory",
            "YunhuMessageSend",
            "YunhuMessageStream",
            "YunhuServBotFollow",
            "YunhuServBotSetting",
            "YunhuServBotUnFollow",
            "YunhuServButtonClick",
            "YunhuServCommand",
            "YunhuServGroupJoin",
            "YunhuServGroupLeave",
            "YunhuServMenuClick",
            "YunhuServNormal",
            "YunhuServer",
        ]

    def Status(self):
        for p in self.all_packages:
            if hasattr(self.framer, p):
                self.logger(f"{p} loaded")
                continue
            self.logger(f"{p} not loaded")
