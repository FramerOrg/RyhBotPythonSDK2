moduleInfo = {
    "author": "r1a",
    "description": "YunhuAPI - Message Send Module",
    "hooker": False,
}

from .module import moduleMain
