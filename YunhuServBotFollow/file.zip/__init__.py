moduleInfo = {
    "author": "r1a",
    "description": "YunhuServer - Bot Follow Message Handler",
    "hooker": False,
}

from .module import moduleMain
