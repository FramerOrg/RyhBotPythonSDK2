moduleInfo = {
    "author": "r1a",
    "description": "YunhuServer - Bot Setting Message Handler",
    "hooker": False,
}

from .module import moduleMain
