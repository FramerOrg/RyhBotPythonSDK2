moduleInfo = {
    "author": "r1a",
    "description": "YunhuAPI - History Module",
    "hooker": False,
}

from .module import moduleMain
