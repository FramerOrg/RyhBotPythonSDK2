moduleInfo = {
    "author": "r1a",
    "description": "YunhuServer - Group Join Message Handler",
    "hooker": False,
}

from .module import moduleMain
