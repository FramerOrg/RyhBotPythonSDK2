class moduleMain:
    def __init__(self, framer, logger):
        self.framer = framer
        self.logger = logger

        self.on = "group.join"
        self.handlers = []

    def __call__(self, handler):
        self.handlers.append(handler)

    def Pipe(self, v_in, return_next, resolve, reject):
        if v_in is None:
            reject("No input data")
            return
        if v_in["header"]["eventType"] != self.on:
            return_next(v_in)
            return
        self.OnRecv(v_in)
        return_next(v_in)

    def OnRecv(self, data):
        for h in self.handlers:
            h(data)
