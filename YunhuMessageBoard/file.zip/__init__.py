moduleInfo = {
    "author": "r1a",
    "description": "YunhuAPI - Board Management Module",
    "hooker": False,
}

from .module import moduleMain
